#!/bin/python3

from random import randint
player = input("r for ROCK, p for PAPER or s for SCISSORS ?")
if player=="r":
  art="O"
elif player=="p":
  art="__"
else:
  art=">8"
print(art,"vs",end=" ")
#print("Test for line change")

chosen = randint(1,3)

if chosen==1:
  chosen="r"
  art="O"
elif chosen ==2:
  chosen="p"
  art="__"
else:
  chosen="s"
  art=">8"
  
print(art)  
  
if player == chosen:
  print("DRAW!")
elif player > chosen:
  print("Player wins!")
else:
  print("Computer wins!")