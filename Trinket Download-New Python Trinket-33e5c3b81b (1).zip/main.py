#!/bin/python3
from turtle import *
from random import randint

#Formation of race track

speed(0)
penup()
goto(-140,140)
for checkpoint in range(16):
  forward(15)
  write(checkpoint,align='center')
  right(90)
  forward(10)
  pendown()
  forward(150)
  penup()
  backward(160)
  left(90)
  
#Participants

tits = Turtle()
tits.color("#ECEC36")
tits.shape("turtle")
tits.penup()
tits.goto(-160,120)
tits.right(360)
tits.write("TITS")

x=Turtle()
x.color("#D41111")
x.shape("turtle")
x.penup()
x.goto(-160,100)
x.right(360)
x.write("AKSHAY")

#starting the race

for step in range(60):
  if step%2==0:
    tits.pendown()
    x.pendown()
  else:
    tits.penup()
    x.penup()
  
  tits.forward(randint(4,8))
  x.forward(randint(4,8))



