#!/bin/python3
from turtle import *
screen =Screen()
screen.setup(600,300)
colours={"titsbg":"#000000","titstext":"#F01D1D"}
screen.bgcolor(colours["titsbg"])

#print(colours["titsbg"])

color(colours["titstext"])
style=('jokerman','15')
write('TITS, My handwriting was better than yours in class 3',font=style,align='center')
hideturtle()
