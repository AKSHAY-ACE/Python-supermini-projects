#!/bin/python3
from turtle import *
from random import randint

#Formation of race track

speed(0)
penup()
goto(-140,140)
for checkpoint in range(16):
  forward(15)
  write(checkpoint,align='center')
  right(90)
  forward(10)
  pendown()
  forward(150)
  penup()
  backward(160)
  left(90)
  
#Participants

y = Turtle()
y.color("#ECEC36")
y.shape("turtle")
y.penup()
y.goto(-160,100)
y.right(360)
y.write("AKSHAY GOD")

x=Turtle()
x.color("#D41111")
x.shape("turtle")
x.penup()
x.goto(-160,50)
x.right(360)
x.write("SURAJ THE LOSER")

x.speed(1)
y.speed(1)

#starting the race

for step in range(50):
  if step%2==0:
    y.pendown()
    x.pendown()
  else:
    y.penup()
    x.penup()
  
  y.forward(randint(4,8))
  x.forward(randint(4,8))
  
  
  
  



